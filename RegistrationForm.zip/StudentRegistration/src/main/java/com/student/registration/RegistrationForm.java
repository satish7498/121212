package com.student.registration;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationForm
 */
@WebServlet("/RegistrationForm")
public class RegistrationForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("In Registration Form...");
    	response.setContentType("text/html");
    	String firstName=request.getParameter("FirstName");
    	String lastName=request.getParameter("LastName");
    	String email=request.getParameter("emailId");
    	String number=request.getParameter("MobileNumber");
    	String password1=request.getParameter("password");
    	String password2=request.getParameter("password");
    	PrintWriter out=response.getWriter();
    	
    	if(password1.equals(password2)) {
    		response.getWriter();
    		System.out.println("Registration completed...");
    		request.setAttribute("data",firstName);
			RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);	
    	}
    	else {
    		System.out.println("Password Mismatched....");
    		RequestDispatcher rd=request.getRequestDispatcher("failuer.jsp");
			rd.forward(request, response);
    	}
    	
    
    }
}
